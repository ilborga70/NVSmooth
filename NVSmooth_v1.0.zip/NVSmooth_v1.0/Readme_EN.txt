====================================================================
                  NVSmooth v1.0 - NVIDIA Stutter Fix
             Created by: Igor Borgacci (ilborga70)
====================================================================

NVSmooth automatically applies an optimized global profile to your 
NVIDIA graphics drivers to reduce micro-stuttering, stabilize 
frametimes, and improve overall gaming smoothness.

It does not require NVIDIA Profile Inspector or any other third-party 
software to be installed.

--------------------------------------------------------------------
REQUIREMENTS
--------------------------------------------------------------------
- Windows 10 / 11 (64-bit)
- NVIDIA graphics card with updated drivers
- Administrator privileges

--------------------------------------------------------------------
HOW TO USE
--------------------------------------------------------------------
1. Close any running games or 3D applications.
2. Double-click NVSmooth.exe (or run as Administrator).
3. Confirm the Windows User Account Control (UAC) prompt.
4. Wait for the confirmation message!

Note: If your PC uses an older NVIDIA GPU (e.g., GTX series without 
DLSS support), the tool will still apply all other compatible 
optimizations without throwing errors.

--------------------------------------------------------------------
WHAT IT MODIFIES IN THE NVIDIA DRIVER
--------------------------------------------------------------------
* Shader Disk Cache Size (100 GB):
  Prevents the driver from continuously deleting compiled shaders, 
  eliminating sudden freezes during gameplay.

* Adaptive V-Sync (Force On + Tear Control Adaptive):
  Eliminates screen tearing when FPS matches your monitor's refresh 
  rate and instantly disables V-Sync if FPS drops below the threshold, 
  preventing abrupt framerate drops.

* Power Management Mode ("Prefer Maximum Performance"):
  Keeps GPU clock speeds stable and avoids micro-stutters caused by 
  constant power state transitions.

* Global G-SYNC / VRR Disabled:
  Works in tandem with Adaptive V-Sync and eliminates brightness 
  flickering (VRR flicker) on OLED and VA monitors.

* Maximum Refresh Rate & Low Latency (FRL):
  Forces your monitor's maximum refresh rate at all times while 
  keeping input lag to a minimum.

* Global DLSS Overrides (RTX GPUs only):
  Forces the latest driver-level DLSS libraries with the "Quality" 
  preset to keep GPU load balanced and frametimes flat.

--------------------------------------------------------------------
HOW TO RESTORE DEFAULT SETTINGS
--------------------------------------------------------------------
If you wish to revert to the original NVIDIA defaults:
1. Open the "NVIDIA Control Panel" (right-click on your Desktop).
2. Go to "Manage 3D settings" -> "Global Settings" tab.
3. Click the "Restore" button at the bottom right and click "Apply".

--------------------------------------------------------------------
CREDITS
--------------------------------------------------------------------
Development & Profile Optimization: Igor Borgacci (ilborga70)
====================================================================
